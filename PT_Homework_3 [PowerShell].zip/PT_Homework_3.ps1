# grant access to execute the script
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned

# ------------------------ SETUP SITE ------------------------
# Setup environment
$webServerFolder = 'C:\inetpub\wwwroot'
$siteName = 'TASK3_SYS_INFO'
$siteFolder = “$webServerFolder\$siteName\”
$rootSiteFile = 'index.html'
$siteFilePath = “$webServerFolder\$siteName\$rootSiteFile”
$port = '50000'
$uri = 'localhost'
$protocol = 'http'
$siteAddress = "*:$port:"
$siteUrl = "$protocol://$uri:$port/"

# Creating site
# Remove site if exist
if (Get-IISSite -Name $siteName) {
	Remove-IISSite -Name $siteName
}

# Remove folder if exist
if (Test-Path -Path $Folder) {
    Get-ChildItem $siteFolder -Include *.* -Recurse | ForEach  { $_.Delete()}
}


# Installing the Web server
Install-WindowsFeature -name Web-Server -IncludeManagementTools

# Installing the IISAdministration Module
Install-Module -Name 'IISAdministration'

# Creating the Web Folder
New-Item -ItemType Directory -Name $siteName -Path $webServerFolder

# Creating the Web Page with system info
Get-WmiObject -Class Win32_ComputerSystem | ConvertTo-Html | Out-File $siteFilePath

# Creating root file of site
New-IISSite -Name $siteName -PhysicalPath $siteFolder -BindingInformation $siteAddress

# Launch site in default browser
Start-Process $siteUrl # or IE [system.Diagnostics.Process]::Start("iexplore",$siteUrl) # 


# ------------------------ LABORATORY WORK ------------------------
$outFilePath = './task.txt'
$folder = 'C:\Windows'
# ---- 4 ----

# files | sort by size | filter by size > 10000
Get-Childitem -Path $folder -File –Recurse | Where-Object {$_.Length -gt 1kb} | Sort-Object -Property Length
# files, directories | sort by date | filter name starts with SY
Get-Childitem -Path $folder –Recurse | Where-Object {$_.Name.StartsWtih('SY')} | Sort-Object -Property CreationTime
# directories | sort by name | filter name ends with S or T
Get-Childitem -Path $folder -Directory –Recurse | Where-Object {$_.Name.EndsWith('S') -or $_.Name.EndsWith('T')} | Sort-Object -Property Name
# file extention *.exe | sort by size | filter by size > 50000
Get-Childitem -Path $folder -File –Recurse -Include *.exe | Where-Object {$_.Length -gt 5kb} | Sort-Object -Property Length
# file extention *.jpg | sort by name
Get-Childitem -Path $folder -File –Recurse -Include *.jpg | Sort-Object -Property Name

# ---- 5 ----
Get-Process | Tee-Object -FilePath $filePath | Measure-Object

# ---- 6 | 7 ----
Get-Process | Where-Object BasePriority -gt 7 | Select-Object Name,BasePriority,Company | Sort-Object name | Out-File $outFilePath
# ... other scripts in the task are the same

# ---- 8 ----
$startFolder = 'C:\Windows'
Get-ChildItem -Path $startFolder -Include *.bmp,*.jpg -Recurse -File | Measure-Object Length -Sum

# ---- 9 ----
Get-WmiObject Win32_Processor

# ---- 10 ----
$count = 10

# Get-ChildItem
1..$count | foreach {Measure-Command {Get-ChildItem -Path $folder}} | Measure-Object TotalMilliseconds -Max -Min -Average
# Get-Process
1..$count | foreach {Measure-Command {Get-Process}} | Measure-Object TotalMilliseconds -Max -Min -Average

# ---- 11 ----
# I don't have time to do this task
